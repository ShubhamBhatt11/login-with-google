<?php
session_start();
if(!isset($_SESSION['access_token']))
{
    header('login.php');
    exit();
}

?>

<!doctype html>
<html lang="en">
    <head>
        <title>login with google</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1.0,maximum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </head>
    <body>
    <div class="container" style="margin-top:100px;">
        <div class="row justify-content-center">
            <div class="col-md-3" align="center">
            <img src="<?php echo $_SESSION['picture'];  ?>" alt="">
            </div>
            <div class="col-md-9" align="center">
            <table class="table table-hover table bordered">
            
            <tbody>
            
            <tr>
            <td>ID</td>
            <td><?php echo $_SESSION['id'] ?></td>
            </tr>

            <tr>
            <td>FIRST NAME</td>
            <td><?php echo $_SESSION['givenName'] ?></td>
            </tr>

            <tr>
            <td>LAST NAME</td>
            <td><?php echo $_SESSION['familyName'] ?></td>
            </tr>
            
            <tr>
            <td>EMAIL</td>
            <td><?php echo $_SESSION['email'] ?></td>
            </tr>
            
            <tr>
            <td>GENDER</td>
            <td><?php echo $_SESSION['gender'] ?></td>
            </tr>
            
            </tbody>
            </table>
            <a href="logout.php">logout</a>
            </div>
        </div>
    </div>
        <?php
        ?>
    </body>
</html>
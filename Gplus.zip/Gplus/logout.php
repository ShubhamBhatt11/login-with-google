<?php

require_once "config.php";

// $gClient->revokeToken();
session_destroy();
unset($_SESSION['access_token']);
header("Location:login.php");
exit();
?>
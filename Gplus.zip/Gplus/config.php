<?php
    session_start();
    require_once "Google/vendor/autoload.php";
    $gClient=new Google_Client();
    $guzzleClient = new \GuzzleHttp\Client(array( 'curl' => array( CURLOPT_SSL_VERIFYPEER => false, ), ));
    $gClient->setHttpClient($guzzleClient);
    $gClient->setClientId("137536456748-2djid1udmhf1pc2rqu5unpqu5bo4bvkg.apps.googleusercontent.com");
    //137536456748-2djid1udmhf1pc2rqu5unpqu5bo4bvkg.apps.googleusercontent.com
    $gClient->setClientSecret("vez9JtQaHD70_SUG2eM-xkC0");
    //vez9JtQaHD70_SUG2eM-xkC0
    $gClient->setApplicationName("g_login");
    $gClient->setRedirectUri("http://". $_SERVER['HTTP_HOST'] ."/Gplus/callback.php");
    $gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email ");
?>